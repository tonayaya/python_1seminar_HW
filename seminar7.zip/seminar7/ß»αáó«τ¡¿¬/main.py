import init

def button_click():
    init.ui_start()

if __name__ == '__main__':
    button_click()
