from student_database import get_student


def see_rating(last_name):
    """Вызов функции просмотра данных ученика"""
    get_student(last_name)